import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Booknow from "./components/Booknow";
import "../src/style.css";
//import * as serviceWorker from "./serviceWorker";

ReactDOM.render(
  

    <Booknow />
,
  document.getElementById("root")
);
