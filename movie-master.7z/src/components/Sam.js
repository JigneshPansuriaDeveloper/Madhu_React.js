import React, { Component } from "react";

 class Sam extends Component {
  render() {
    return <div>Sam component</div>;
  }
}

export default Sam;
