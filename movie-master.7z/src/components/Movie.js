import React,{Component} from "react";
import { BrowserRouter as Router, Link, Route } from "react-router-dom";
import Booknow from "./Booknow";

export default class  Movie extends Component {
 
  redirectToTarget=(id)=>{
   //sss this.props.history.push(`/movies/${id}`)
  }
  render(){
    return (
      <div className="container">
        {this.props.mdata.map((e, index) => {
          // const style = {
          //   background: `url('/images/${e.Image}.jpg')`
          // };
          return (
            <div className="card">
              
                <div>
                  <ul>
                    <li>
                      {" "}
                      <img src={`/images/${e.Image}.jpg`} key={index} alt="" />
                    </li>
  
                    <li>
                      <span>Name:</span> {e.title}
                    </li>
                    <br></br>
                    <li>
                      <span>Likes:</span> {e.likes}
                    </li>
                    <br></br>
                    <li>
                      <span>Dis Likes:</span> {e.dislikes}
                    </li>
                    <li>
                      <span>Details:</span> {e.details}
                    </li>
                    <li>
                      
                        <Link to={`/movies/${e.id}`} key={e.id}>Book My Show</Link>
                     
                    </li>
                  </ul>
                </div>
                
            </div>
          );
        })}
      </div>
    );
  }
 
}
