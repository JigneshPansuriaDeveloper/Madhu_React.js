import React, { Component } from "react";
import Home from "./Home";
import Sam from '../components/Sam';

import { BrowserRouter as Router, Link, Route,Switch } from "react-router-dom";
 class Booknow extends Component {
  render(props) {
    return (
      <div>
        <Router>
          <Link to="/home">Home</Link>
          <Switch>
          <Route exact  path="/home" component={Home} />
          <Route exact path="/movies/:id" component={Sam}/>
         
          
          </Switch>
        </Router>
      </div>
    );
  }
}

export default Booknow;
